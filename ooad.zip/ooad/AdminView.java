/*
 * Administrators page 
 * 
 */
public class AdminView {
	//void show method
	public void showView()
	 {
		//Default Method
		 System.out.println("This is the Administrators page");
	 }
}
