/*
 * Administrators page 
 * class Userview
 */
public class UserView {
	//void show method
 public void showView()
 {
	 System.out.println("This is the customers page");
 }
}
