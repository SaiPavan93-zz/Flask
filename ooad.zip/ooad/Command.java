/**
 * Command Interface
 */
public interface Command {
 public void execute();
}
